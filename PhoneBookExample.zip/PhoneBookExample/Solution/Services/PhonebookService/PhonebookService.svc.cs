﻿using PhonebookService.DTO;
using PhonebookService.Logic;
using System;
using System.Collections.Generic;
using System.ServiceModel;

namespace PhonebookService
{
    public class PhonebookService : IPhonebookService
    {
        /// <summary>
        /// Populates and caches dummy phonebook entries for testing purposes
        /// </summary>
        /// <returns>void</returns>
        public void WriteDummyEntries()
        {
            try
            {
                PhonebookLogic.WriteDummyEntries();
            }
            catch (Exception ex)
            {
                throw new FaultException<ExceptionDetail>(new ExceptionDetail(ex), ex.Message);
            }
        }

        /// <summary>
        /// Returns a List of Telephone number types
        /// </summary>
        /// <returns>List<PhoneBookNumberType></returns>
        public List<PhoneBookNumberType> GetPhoneBookNumberTypes()
        {
            try
            {
                return PhonebookLogic.GetPhoneBookNumberTypes();
            }
            catch (Exception ex)
            {
                throw new FaultException<ExceptionDetail>(new ExceptionDetail(ex), ex.Message);
            }
        }

        /// <summary>
        /// Loads and caches the phonebook contact entries 
        /// </summary>
        /// <returns>List<PhonebookEntry></returns>
        public List<PhonebookEntry> CachePhonebookEntries()
        {
            try
            {
                return PhonebookLogic.CachePhonebookEntries();
            }
            catch (Exception ex)
            {
                throw new FaultException<ExceptionDetail>(new ExceptionDetail(ex), ex.Message);
            }

        }

        /// <summary>
        /// Add and Updates respective phonebook entries
        /// </summary>
        /// <returns>void</returns>
        public string UpdatePhonebookEntry(PhonebookEntry entry)
        {
            try
            {
                return PhonebookLogic.UpdatePhonebookEntry(entry);
            }
            catch (Exception ex)
            {
                throw new FaultException<ExceptionDetail>(new ExceptionDetail(ex), ex.Message);
            }
        }

        /// <summary>
        /// Deletes a specific phonebook entry
        /// </summary>
        /// <returns>void</returns>
        public void DeletePhonebookEntry(string phonebookEntryId)
        {
            try
            {
                PhonebookLogic.DeletePhonebookEntry(phonebookEntryId);
            }
            catch (Exception ex)
            {
                throw new FaultException<ExceptionDetail>(new ExceptionDetail(ex), ex.Message);
            }
        }
    }
}
