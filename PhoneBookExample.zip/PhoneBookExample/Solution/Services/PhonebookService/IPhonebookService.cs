﻿using PhonebookService.DTO;
using System.Collections.Generic;
using System.ServiceModel;

namespace PhonebookService
{
    [ServiceContract]
    public interface IPhonebookService
    {
        [OperationContract]
        void WriteDummyEntries();

        [OperationContract]
        List<PhoneBookNumberType> GetPhoneBookNumberTypes();

        [OperationContract]
        string UpdatePhonebookEntry(PhonebookEntry entry);

        [OperationContract]
        void DeletePhonebookEntry(string phonebookEntryId);

        [OperationContract]
        List<PhonebookEntry> CachePhonebookEntries();
    }
}
