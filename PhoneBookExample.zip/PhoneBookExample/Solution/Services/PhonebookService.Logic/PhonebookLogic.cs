﻿using Phonebook.DataAccess;
using PhonebookService.DTO;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PhonebookService.Logic
{
    public class PhonebookLogic
    {
        public static List<PhonebookEntry> entries = null;
        public static List<PhoneBookNumberType> GetPhoneBookNumberTypes()
        {
            return PhoneBookNumberType.GetPhoneBookNumberTypes();
        }
        public static List<PhonebookEntry> CachePhonebookEntries()
        {
            if (entries == null)
                entries = PhonebookData.CachePhonebookEntries();

            return entries;
        }

        public static List<PhonebookEntry> CachePhonebookEntries(bool reload)
        {
            if (reload)
            {
                entries = null;
                entries = PhonebookData.CachePhonebookEntries();
            }

            return entries;
        }

        public static PhonebookEntry GetPhonebookEntryById(string phoneBookEntryId)
        {
            CachePhonebookEntries();
            PhonebookEntry entry = null;

            if (entries != null)
                entry = entries.Find(x => x.PhonebookEntryId == phoneBookEntryId);

            return entry;

        }

        public static string UpdatePhonebookEntry(PhonebookEntry entry)
        {
            if (entry == null)
                return string.Empty;

            //insert
            if (entry.PhonebookEntryId == null || Guid.Parse(entry.PhonebookEntryId) == Guid.Empty)
            {
                entry.PhonebookEntryId = string.Format("{0}", Guid.NewGuid());
                if (ValidateDigitPhoneNumber(entry.Numbers))
                {
                    entry.Numbers.ForEach(x => x.PhonebookEntryId = entry.PhonebookEntryId);
                    entries.Add(entry);
                    UpdateData();
                }
                else
                    throw new Exception("Non-numeric value detected within the phone number list entries");
            }
            //update
            else
            {
                PhonebookEntry obj = entries.FirstOrDefault(x => x.PhonebookEntryId == entry.PhonebookEntryId);
                if (obj != null)
                    entries[entries.IndexOf(obj)] = entry;

                UpdateData();
            }

            return entry.PhonebookEntryId;
        }

        /// <summary>
        /// This will never fail as front-end key restrictions are performed to only allow digit type keys.
        /// </summary>
        /// <param name="entries"></param>
        /// <returns>will return false if any of the input number entries are non numeric</returns>
        private static bool ValidateDigitPhoneNumber(List<PhonebookEntryNumber> entries)
        {
            bool pass = true;

            if (entries != null)
            {
                foreach (PhonebookEntryNumber e in entries)
                {
                    int.TryParse(e.Number, out int chk);

                    if (chk < 0)
                    {
                        pass = false;
                        break;
                    }
                }
            }
            return pass;
        }

        public static void DeletePhonebookEntry(string phonebookEntryId)
        {
            entries.RemoveAll(x => x.PhonebookEntryId == phonebookEntryId);
            UpdateData();
        }

        private static void UpdateData()
        {
            PhonebookData.UpdatePhonebookEntries(entries);
        }

        public static void WriteDummyEntries()
        {
            string g1 = string.Format("{0}", Guid.NewGuid());
            List<PhonebookEntryNumber> numbers1 = new List<PhonebookEntryNumber>
                {
                    new PhonebookEntryNumber { Number = "0849108995", PhonebookEntryId = g1, NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                    new PhonebookEntryNumber { Number = "0837008091", PhonebookEntryId = g1, NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                };
            entries = new List<PhonebookEntry>
                {
                    new PhonebookEntry {
                        PhonebookEntryId = g1, FirstName = string.Format("{0}",Guid.NewGuid()), Surname = string.Format("{0}",Guid.NewGuid()), Numbers = numbers1, DateCreated = DateTime.Now},
                };

            string g2 = string.Format("{0}", Guid.NewGuid());
            List<PhonebookEntryNumber> numbers2 = new List<PhonebookEntryNumber>
                {
                    new PhonebookEntryNumber { Number = "0849100000", PhonebookEntryId = g2, NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                    new PhonebookEntryNumber { Number = "0837008888", PhonebookEntryId = g2, NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                };
            entries.Add(
                new PhonebookEntry
                {
                    PhonebookEntryId = g2,
                    FirstName = string.Format("{0}", Guid.NewGuid()),
                    Surname = string.Format("{0}", Guid.NewGuid()),
                    Numbers = numbers2,
                    DateCreated = DateTime.Now
                });

            string g3 = string.Format("{0}", Guid.NewGuid());
            List<PhonebookEntryNumber> numbers3 = new List<PhonebookEntryNumber>
                {
                    new PhonebookEntryNumber { Number = "0120000000", PhonebookEntryId = g3, NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                    new PhonebookEntryNumber { Number = "0130000000", PhonebookEntryId = g3, NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                };
            entries.Add(
                new PhonebookEntry
                {
                    PhonebookEntryId = g3,
                    FirstName = string.Format("{0}", Guid.NewGuid()),
                    Surname = string.Format("{0}", Guid.NewGuid()),
                    Numbers = numbers3,
                    DateCreated = DateTime.Now
                });

            string g4 = string.Format("{0}", Guid.NewGuid());
            List<PhonebookEntryNumber> numbers4 = new List<PhonebookEntryNumber>
                {
                    new PhonebookEntryNumber { Number = "0134000000", PhonebookEntryId = g4, NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                    new PhonebookEntryNumber { Number = "0140000000", PhonebookEntryId = g4, NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                };
            entries.Add(
                new PhonebookEntry
                {
                    PhonebookEntryId = g4,
                    FirstName = string.Format("{0}", Guid.NewGuid()),
                    Surname = string.Format("{0}", Guid.NewGuid()),
                    Numbers = numbers4,
                    DateCreated = DateTime.Now
                });

            string g5 = string.Format("{0}", Guid.NewGuid());
            List<PhonebookEntryNumber> numbers5 = new List<PhonebookEntryNumber>
                {
                    new PhonebookEntryNumber { Number = "0160000000", PhonebookEntryId = g5, NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                    new PhonebookEntryNumber { Number = "0540000000", PhonebookEntryId = g5, NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                };
            entries.Add(
                new PhonebookEntry
                {
                    PhonebookEntryId = g5,
                    FirstName = string.Format("{0}", Guid.NewGuid()),
                    Surname = string.Format("{0}", Guid.NewGuid()),
                    Numbers = numbers5,
                    DateCreated = DateTime.Now
                });

            PhonebookData.UpdatePhonebookEntries(entries);
        }
    }
}
