﻿using Newtonsoft.Json;
using PhonebookService.DTO;
using System.Collections.Generic;
using System.Configuration;
using System.IO;

namespace Phonebook.DataAccess
{
    public class PhonebookData
    {
        private static readonly string DBPathConnectionString = ConfigurationManager.AppSettings["DBPathConnectionString"];
        private static readonly string dir = Path.GetDirectoryName(DBPathConnectionString);

        public static List<PhonebookEntry> CachePhonebookEntries()
        {
            if (File.Exists(DBPathConnectionString) == true)
            {
                using (StreamReader r = new StreamReader(DBPathConnectionString))
                {
                    string json = r.ReadToEnd();
                    return JsonConvert.DeserializeObject<List<PhonebookEntry>>(json);
                }
            }
            else return new List<PhonebookEntry>();
        }

        public static void UpdatePhonebookEntries(List<PhonebookEntry> entries)
        {
            if (File.Exists(dir) == false)
                Directory.CreateDirectory(dir);

            string jsonData = JsonConvert.SerializeObject(entries, Formatting.None);
            System.IO.File.WriteAllText(DBPathConnectionString, jsonData);
        }
    }
}
