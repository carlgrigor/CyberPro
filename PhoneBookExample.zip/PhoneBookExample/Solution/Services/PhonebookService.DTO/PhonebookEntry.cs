﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

/// <summary>
/// This Business Entity represents the person to which the list of numbers belong of a specific type belongs to
/// Note, these phonebook entries are purely focussed of type person
/// </summary>

namespace PhonebookService.DTO
{
    [DataContract]
    public class PhonebookEntry
    {
        [DataMember]
        public string PhonebookEntryId { get; set; }
        [DataMember]
        public string Surname { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public List<PhonebookEntryNumber> Numbers { get; set; }
        [DataMember]
        public DateTime DateCreated { get; set; }
    }
}
