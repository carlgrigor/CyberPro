﻿using System;
using System.Runtime.Serialization;

namespace PhonebookService.DTO
{
    [DataContract]
    public class PhonebookEntryNumber
    {
        [DataMember]
        public string PhonebookEntryId { get; set; }
        [DataMember]
        public string NumberType { get; set; }
        [DataMember]
        public string Number { get; set; }
        [DataMember]
        public DateTime DateCreated { get; set; }
        [DataMember]
        public DateTime DateUpdated { get; set; }
    }
}
