﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace PhonebookService.DTO
{
    public class PhoneBookNumberType
    {
        [DataMember]
        public string NumberType { get; set; }

        private static List<PhoneBookNumberType> lstphoneBookNumberTypes = null;
        /// <summary>
        /// Returns a List of Telephone number types
        /// </summary>
        /// <returns>List<PhoneBookNumberType></returns>
        public static List<PhoneBookNumberType> GetPhoneBookNumberTypes()
        {
            if (lstphoneBookNumberTypes is null)
            {
                lstphoneBookNumberTypes = new List<PhoneBookNumberType>
                {
                    new PhoneBookNumberType { NumberType = "Mobile" },
                    new PhoneBookNumberType { NumberType = "Home" },
                    new PhoneBookNumberType { NumberType = "Work" },
                    new PhoneBookNumberType { NumberType = "Work Fax" },
                    new PhoneBookNumberType { NumberType = "Home Fax" }
                };
            }

            return lstphoneBookNumberTypes;

        }
    }
}
