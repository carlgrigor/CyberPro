﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using PhonebookService.DTO;
using PhonebookService.Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PhonebookService.Tests.UnitTests
{
    [TestClass()]
    public class PhonebookLogicTests
    {
        //Load The initial Phonebook Entries into Cache
        public static List<PhonebookEntry> _entries = PhonebookLogic.CachePhonebookEntries();

        //Set paramater _phoneNumberEntryId as this program will delete the newly created entry 
        private static string _phoneNumberEntryId = string.Empty;

        /// <summary>
        /// Add a new Phonebook entry and assert whether the entry was committed
        /// </summary>
        [TestMethod()]
        public void AddPhonebookEntry()
        {
            _entries = PhonebookLogic.CachePhonebookEntries();

            //Add Number
            List<PhonebookEntryNumber> numbers = new List<PhonebookEntryNumber>
                {
                    new PhonebookEntryNumber { Number = GenerateNewNumber(), NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                    new PhonebookEntryNumber { Number = GenerateNewNumber(), NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now },
                };

            string firstName = string.Format("{0}", Guid.NewGuid());
            string surname = string.Format("{0}", Guid.NewGuid());

            PhonebookLogic.UpdatePhonebookEntry(new PhonebookEntry
            {
                FirstName = firstName,
                Surname = surname,
                DateCreated = DateTime.Now,
                Numbers = numbers
            }); ;

            _entries = PhonebookLogic.CachePhonebookEntries(true);

            PhonebookEntry entry = _entries.Find(x => x.FirstName == firstName && x.Surname == surname);
            _phoneNumberEntryId = entry != null ? entry.PhonebookEntryId : string.Empty;
            Assert.IsTrue(string.IsNullOrEmpty(_phoneNumberEntryId) == false);
        }

        [TestMethod()]
        public void CachePhoneBookNumberTypes()
        {
            List<PhoneBookNumberType> types = PhonebookLogic.GetPhoneBookNumberTypes();
            Assert.IsTrue(types.Exists(x => x.NumberType == "Mobile"));
        }

        /// <summary>
        /// Delete a Phonebook Entry and Assert whether the deletion has been committed.
        /// </summary>
        [TestMethod()]
        public void DeletePhonebookEntry()
        {
            if (_phoneNumberEntryId != string.Empty)
            {
                PhonebookLogic.DeletePhonebookEntry(_phoneNumberEntryId);

                _entries = PhonebookLogic.CachePhonebookEntries();
                Assert.IsTrue(_entries.Exists(x => x.PhonebookEntryId == _phoneNumberEntryId) == false);
            }
        }

        /// <summary>
        /// Add a number to an Existing Phonebook Entry and Assert whether the entry was committed
        /// </summary>
        [TestMethod()]
        public void UpdatePhonebookEntry()
        {
            _entries = PhonebookLogic.CachePhonebookEntries();
            PhonebookEntry entry = _entries != null && _entries.Count != 0 ? _entries.FirstOrDefault() : null;

            string telNumber = GenerateNewNumber();
            if (entry != null)
            {
                PhonebookEntryNumber number = new PhonebookEntryNumber { PhonebookEntryId = entry.PhonebookEntryId, Number = telNumber, NumberType = "Mobile", DateCreated = DateTime.Now, DateUpdated = DateTime.Now };
                entry.Numbers.Add(number);
                PhonebookLogic.UpdatePhonebookEntry(entry);
            }

            entry = PhonebookLogic.GetPhonebookEntryById(entry.PhonebookEntryId);
            Assert.IsTrue(entry.Numbers.Exists(x => x.PhonebookEntryId == entry.PhonebookEntryId && x.Number == telNumber));
        }

        public static string GenerateNewNumber()
        {
            Random random = new Random();
            StringBuilder output = new StringBuilder();

            for (int i = 0; i < 10; i++)
                output.Append(random.Next(0, 10));

            return output.ToString();
        }
    }
}
