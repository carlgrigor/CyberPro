﻿using ComponentFactory.Krypton.Toolkit;
using DMS.UI;
using PhoneBook.PhonebookService;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

namespace PhoneBook.Forms
{
    public partial class UpdateContact : KryptonForm
    {
        private ProgressControl _progressControl = null;
        private List<PhoneBookNumberType> _phoneNumberTypes = null;
        private bool _edit = false;

        /// <summary>
        /// Public variable to place this form in edit mode for phone entries
        /// </summary>
        public bool Edit
        {
            get
            {
                return _edit;
            }
            set
            {
                _edit = value;
                if (_edit)
                    hdrPhonebook.Values.Description = "Edit Contact Details";
                else
                    hdrPhonebook.Values.Description = "Add Contact Details";
            }
        }
        public PhonebookEntry PhonebookEntry { get; set; } = null;
        public UpdateContact()
        {
            InitializeComponent();
            Startup();
        }

        private void Startup()
        {
            _progressControl = new ProgressControl();
            _progressControl.Show(this);

            bindDataWorker.RunWorkerAsync();
        }
        /// <summary>
        /// The Phone number types are cached in the service layer for quick access purposes.
        /// </summary>
        private void BindData()
        {
            PhonebookServiceClient client = null;
            try
            {
                client = new PhonebookServiceClient();
                _phoneNumberTypes = client.GetPhoneBookNumberTypes();
                client.Close();
            }
            catch (Exception ex)
            {
                //ex.Message should only be used for debugging purposes, a more user friendly msg must be displayed to end user
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (client != null && client.State != System.ServiceModel.CommunicationState.Closed)
                    client.Abort();
            }
        }
        private void bindDataWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            BindData();
        }

        private void bindDataWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                MessageBox.Show("Could not load phone number types", "Error", MessageBoxButtons.OK);
            }
            else
                //Bind Data
                if (_phoneNumberTypes != null)
                bsPhoneNumberTypes.DataSource = _phoneNumberTypes;

            bsPhonebookEntry.DataSource = PhonebookEntry ?? new PhonebookEntry { DateCreated = DateTime.Now};

            if (!_edit)
            {
                PhonebookEntry = PhonebookEntry ?? new PhonebookEntry { DateCreated = DateTime.Now };
                PhonebookEntry.Numbers = new List<PhonebookEntryNumber> { 
                    new PhonebookEntryNumber { 
                        Number = "", 
                        NumberType = "", 
                        DateCreated = DateTime.Now, 
                        DateUpdated = DateTime.Now } };
            }

            if (_progressControl != null)
                _progressControl.Dispose();
        }

        private void btnSaveContact_Click(object sender, EventArgs e)
        {
            bsPhonebookEntry.EndEdit();

            if (ValidatePhoneEntries())
                this.DialogResult = DialogResult.OK;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Dispose();
        }


        private void dgPhonebookEntries_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            e.Control.KeyPress -= new KeyPressEventHandler(Column_KeyPress);
            if (dgPhonebookEntries.CurrentCell.ColumnIndex == colNumber.Index) //Desired Column
            {
                if (e.Control is TextBox tb)
                    tb.KeyPress += new KeyPressEventHandler(Column_KeyPress);
            }
        }

        /// <summary>
        /// This method Validates that the key presses are of type numeric values
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Column_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }
        /// <summary>
        /// This method ensure that the date is in a correct state
        /// </summary>
        private void SetValues()
        {
            bsNumbers.EndEdit(); //commit number updates
            bsPhonebookEntry.EndEdit(); //commit phonebook entry updates

            if (((PhonebookEntry)bsPhonebookEntry.Current).Numbers != null)
            {
                PhonebookEntry = (PhonebookEntry)bsPhonebookEntry.Current;
                //remove last defualt added row
                PhonebookEntry.Numbers.RemoveAll(x => string.IsNullOrEmpty(x.Number) && string.IsNullOrEmpty(x.NumberType));
            }
        }

        /// <summary>
        /// This method performs basic validation of entered information
        /// </summary>
        /// <returns>false if validation passes</returns>
        private bool ValidatePhoneEntries()
        {
            string msg = string.Empty;

            SetValues();

            foreach (PhonebookEntryNumber n in PhonebookEntry.Numbers)
            {
                //set the create and update date for the records being saved
                n.DateUpdated = DateTime.Now;
                n.DateCreated = Edit ? n.DateCreated : DateTime.Now;//only set Date Created when not in edit mode

                if (!string.IsNullOrEmpty(n.NumberType) && string.IsNullOrEmpty(n.Number))
                    msg = "Please provide a telephone number when a phone type is selected";

                if (!string.IsNullOrEmpty(n.Number) && n.Number.Length != 10)
                    msg = string.Format("Please ensure that you enter a valid phone number that consists of 10 digits, number {0} only has {1} digits", n.Number, n.Number.Length);

                if (!string.IsNullOrEmpty(msg))
                    break;
            }

            if (!string.IsNullOrEmpty(msg))
                MessageBox.Show(msg, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            return string.IsNullOrEmpty(msg);
        }

        private void dgPhonebookEntries_DefaultValuesNeeded(object sender, DataGridViewRowEventArgs e)
        {
            e.Row.Cells["colDateCreated"].Value = DateTime.Now;
        }

        private void dgPhonebookEntries_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {

        }
        /// <summary>
        /// Closes the form on Esc Key Press
        /// </summary>
        /// <param name="keyData"></param>
        /// <returns>if(keyData == Keys.Escape) then true</returns>
        protected override bool ProcessDialogKey(Keys keyData)
        {
            if (Form.ModifierKeys == Keys.None && keyData == Keys.Escape)
            {
                this.DialogResult = DialogResult.Cancel;
                this.Dispose();
                return true;
            }
            return base.ProcessDialogKey(keyData);
        }
    }
}
