﻿namespace PhoneBook.Forms
{
    partial class UpdateContact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateContact));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlDetails = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.hdrActions = new ComponentFactory.Krypton.Toolkit.KryptonHeader();
            this.btnSaveContact = new ComponentFactory.Krypton.Toolkit.ButtonSpecAny();
            this.btnCancel = new ComponentFactory.Krypton.Toolkit.ButtonSpecAny();
            this.kryptonHeaderGroup1 = new ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup();
            this.kryptonPanel1 = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.lblSurname = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.txtSurname = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.bsPhonebookEntry = new System.Windows.Forms.BindingSource(this.components);
            this.lblName = new ComponentFactory.Krypton.Toolkit.KryptonLabel();
            this.txtName = new ComponentFactory.Krypton.Toolkit.KryptonTextBox();
            this.hdrDetails = new ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup();
            this.pnlContactDetails = new ComponentFactory.Krypton.Toolkit.KryptonPanel();
            this.dgPhonebookEntries = new ComponentFactory.Krypton.Toolkit.KryptonDataGridView();
            this.bsPhoneNumberTypes = new System.Windows.Forms.BindingSource(this.components);
            this.bsNumbers = new System.Windows.Forms.BindingSource(this.components);
            this.hdrPhonebook = new ComponentFactory.Krypton.Toolkit.KryptonHeader();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewImageColumn2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.bindDataWorker = new System.ComponentModel.BackgroundWorker();
            this.numberTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.colNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDateCreated = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.pnlDetails)).BeginInit();
            this.pnlDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup1.Panel)).BeginInit();
            this.kryptonHeaderGroup1.Panel.SuspendLayout();
            this.kryptonHeaderGroup1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel1)).BeginInit();
            this.kryptonPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsPhonebookEntry)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hdrDetails)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hdrDetails.Panel)).BeginInit();
            this.hdrDetails.Panel.SuspendLayout();
            this.hdrDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pnlContactDetails)).BeginInit();
            this.pnlContactDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgPhonebookEntries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPhoneNumberTypes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsNumbers)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlDetails
            // 
            this.pnlDetails.Controls.Add(this.hdrActions);
            this.pnlDetails.Controls.Add(this.kryptonHeaderGroup1);
            this.pnlDetails.Controls.Add(this.hdrDetails);
            this.pnlDetails.Controls.Add(this.hdrPhonebook);
            this.pnlDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlDetails.Location = new System.Drawing.Point(0, 0);
            this.pnlDetails.Margin = new System.Windows.Forms.Padding(4);
            this.pnlDetails.Name = "pnlDetails";
            this.pnlDetails.Padding = new System.Windows.Forms.Padding(4);
            this.pnlDetails.Size = new System.Drawing.Size(800, 450);
            this.pnlDetails.TabIndex = 5;
            // 
            // hdrActions
            // 
            this.hdrActions.ButtonSpecs.AddRange(new ComponentFactory.Krypton.Toolkit.ButtonSpecAny[] {
            this.btnSaveContact,
            this.btnCancel});
            this.hdrActions.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.hdrActions.HeaderStyle = ComponentFactory.Krypton.Toolkit.HeaderStyle.Secondary;
            this.hdrActions.Location = new System.Drawing.Point(4, 414);
            this.hdrActions.Margin = new System.Windows.Forms.Padding(4);
            this.hdrActions.Name = "hdrActions";
            this.hdrActions.Size = new System.Drawing.Size(792, 32);
            this.hdrActions.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)((((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Bottom) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.hdrActions.TabIndex = 3;
            this.hdrActions.Values.Description = " ";
            this.hdrActions.Values.Heading = "";
            this.hdrActions.Values.Image = null;
            // 
            // btnSaveContact
            // 
            this.btnSaveContact.Edge = ComponentFactory.Krypton.Toolkit.PaletteRelativeEdgeAlign.Far;
            this.btnSaveContact.Image = global::PhoneBook.Properties.Resources.save;
            this.btnSaveContact.Text = "Save";
            this.btnSaveContact.UniqueName = "00A3D7678CDD41CFEA88B5F5D74732C7";
            this.btnSaveContact.Click += new System.EventHandler(this.btnSaveContact_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Edge = ComponentFactory.Krypton.Toolkit.PaletteRelativeEdgeAlign.Near;
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UniqueName = "968E0E61B9FF414484A5C23E3A807403";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // kryptonHeaderGroup1
            // 
            this.kryptonHeaderGroup1.Dock = System.Windows.Forms.DockStyle.Top;
            this.kryptonHeaderGroup1.HeaderStylePrimary = ComponentFactory.Krypton.Toolkit.HeaderStyle.Secondary;
            this.kryptonHeaderGroup1.HeaderVisibleSecondary = false;
            this.kryptonHeaderGroup1.Location = new System.Drawing.Point(4, 42);
            this.kryptonHeaderGroup1.Margin = new System.Windows.Forms.Padding(4);
            this.kryptonHeaderGroup1.Name = "kryptonHeaderGroup1";
            // 
            // kryptonHeaderGroup1.Panel
            // 
            this.kryptonHeaderGroup1.Panel.Controls.Add(this.kryptonPanel1);
            this.kryptonHeaderGroup1.Size = new System.Drawing.Size(792, 130);
            this.kryptonHeaderGroup1.TabIndex = 6;
            this.kryptonHeaderGroup1.ValuesPrimary.Heading = "Contact Details";
            this.kryptonHeaderGroup1.ValuesPrimary.Image = null;
            // 
            // kryptonPanel1
            // 
            this.kryptonPanel1.Controls.Add(this.lblSurname);
            this.kryptonPanel1.Controls.Add(this.txtSurname);
            this.kryptonPanel1.Controls.Add(this.lblName);
            this.kryptonPanel1.Controls.Add(this.txtName);
            this.kryptonPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kryptonPanel1.Location = new System.Drawing.Point(0, 0);
            this.kryptonPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.kryptonPanel1.Name = "kryptonPanel1";
            this.kryptonPanel1.Padding = new System.Windows.Forms.Padding(4);
            this.kryptonPanel1.Size = new System.Drawing.Size(790, 103);
            this.kryptonPanel1.TabIndex = 5;
            // 
            // lblSurname
            // 
            this.lblSurname.Location = new System.Drawing.Point(20, 55);
            this.lblSurname.Name = "lblSurname";
            this.lblSurname.Size = new System.Drawing.Size(72, 24);
            this.lblSurname.TabIndex = 3;
            this.lblSurname.Values.Text = "Surname";
            // 
            // txtSurname
            // 
            this.txtSurname.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPhonebookEntry, "Surname", true));
            this.txtSurname.Location = new System.Drawing.Point(129, 55);
            this.txtSurname.Name = "txtSurname";
            this.txtSurname.Size = new System.Drawing.Size(235, 27);
            this.txtSurname.TabIndex = 2;
            // 
            // bsPhonebookEntry
            // 
            this.bsPhonebookEntry.DataSource = typeof(PhoneBook.PhonebookService.PhonebookEntry);
            // 
            // lblName
            // 
            this.lblName.Location = new System.Drawing.Point(20, 22);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(85, 24);
            this.lblName.TabIndex = 1;
            this.lblName.Values.Text = "First Name";
            // 
            // txtName
            // 
            this.txtName.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsPhonebookEntry, "FirstName", true));
            this.txtName.Location = new System.Drawing.Point(129, 22);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(235, 27);
            this.txtName.TabIndex = 0;
            // 
            // hdrDetails
            // 
            this.hdrDetails.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.hdrDetails.HeaderStylePrimary = ComponentFactory.Krypton.Toolkit.HeaderStyle.Secondary;
            this.hdrDetails.HeaderVisibleSecondary = false;
            this.hdrDetails.Location = new System.Drawing.Point(4, 175);
            this.hdrDetails.Margin = new System.Windows.Forms.Padding(4);
            this.hdrDetails.Name = "hdrDetails";
            // 
            // hdrDetails.Panel
            // 
            this.hdrDetails.Panel.Controls.Add(this.pnlContactDetails);
            this.hdrDetails.Size = new System.Drawing.Size(792, 239);
            this.hdrDetails.TabIndex = 5;
            this.hdrDetails.ValuesPrimary.Heading = "Number Details - Delete Entries by pressing the delete button on Keyboard";
            this.hdrDetails.ValuesPrimary.Image = null;
            // 
            // pnlContactDetails
            // 
            this.pnlContactDetails.Controls.Add(this.dgPhonebookEntries);
            this.pnlContactDetails.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlContactDetails.Location = new System.Drawing.Point(0, 0);
            this.pnlContactDetails.Margin = new System.Windows.Forms.Padding(4);
            this.pnlContactDetails.Name = "pnlContactDetails";
            this.pnlContactDetails.Padding = new System.Windows.Forms.Padding(4);
            this.pnlContactDetails.Size = new System.Drawing.Size(790, 212);
            this.pnlContactDetails.TabIndex = 5;
            // 
            // dgPhonebookEntries
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgPhonebookEntries.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgPhonebookEntries.AutoGenerateColumns = false;
            this.dgPhonebookEntries.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgPhonebookEntries.ColumnHeadersHeight = 29;
            this.dgPhonebookEntries.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.numberTypeDataGridViewTextBoxColumn,
            this.colNumber,
            this.colDateCreated});
            this.dgPhonebookEntries.DataSource = this.bsNumbers;
            this.dgPhonebookEntries.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgPhonebookEntries.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.dgPhonebookEntries.Location = new System.Drawing.Point(4, 4);
            this.dgPhonebookEntries.Margin = new System.Windows.Forms.Padding(4);
            this.dgPhonebookEntries.Name = "dgPhonebookEntries";
            this.dgPhonebookEntries.RowHeadersVisible = false;
            this.dgPhonebookEntries.RowHeadersWidth = 51;
            this.dgPhonebookEntries.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgPhonebookEntries.Size = new System.Drawing.Size(782, 204);
            this.dgPhonebookEntries.TabIndex = 2;
            this.dgPhonebookEntries.DataError += new System.Windows.Forms.DataGridViewDataErrorEventHandler(this.dgPhonebookEntries_DataError);
            this.dgPhonebookEntries.DefaultValuesNeeded += new System.Windows.Forms.DataGridViewRowEventHandler(this.dgPhonebookEntries_DefaultValuesNeeded);
            this.dgPhonebookEntries.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgPhonebookEntries_EditingControlShowing);
            // 
            // bsPhoneNumberTypes
            // 
            this.bsPhoneNumberTypes.DataSource = typeof(PhoneBook.PhonebookService.PhoneBookNumberType);
            // 
            // bsNumbers
            // 
            this.bsNumbers.DataMember = "Numbers";
            this.bsNumbers.DataSource = this.bsPhonebookEntry;
            // 
            // hdrPhonebook
            // 
            this.hdrPhonebook.AutoSize = false;
            this.hdrPhonebook.Dock = System.Windows.Forms.DockStyle.Top;
            this.hdrPhonebook.Location = new System.Drawing.Point(4, 4);
            this.hdrPhonebook.Margin = new System.Windows.Forms.Padding(4);
            this.hdrPhonebook.Name = "hdrPhonebook";
            this.hdrPhonebook.Size = new System.Drawing.Size(792, 38);
            this.hdrPhonebook.StateCommon.Border.DrawBorders = ((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders)(((ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Top | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Left) 
            | ComponentFactory.Krypton.Toolkit.PaletteDrawBorders.Right)));
            this.hdrPhonebook.TabIndex = 0;
            this.hdrPhonebook.Values.Description = "";
            this.hdrPhonebook.Values.Heading = "Phonebook";
            this.hdrPhonebook.Values.Image = null;
            // 
            // dataGridViewImageColumn1
            // 
            this.dataGridViewImageColumn1.HeaderText = " Edit";
            this.dataGridViewImageColumn1.Image = ((System.Drawing.Image)(resources.GetObject("dataGridViewImageColumn1.Image")));
            this.dataGridViewImageColumn1.MinimumWidth = 6;
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewImageColumn1.Width = 72;
            // 
            // dataGridViewImageColumn2
            // 
            this.dataGridViewImageColumn2.HeaderText = "Delete";
            this.dataGridViewImageColumn2.Image = ((System.Drawing.Image)(resources.GetObject("dataGridViewImageColumn2.Image")));
            this.dataGridViewImageColumn2.MinimumWidth = 6;
            this.dataGridViewImageColumn2.Name = "dataGridViewImageColumn2";
            this.dataGridViewImageColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewImageColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewImageColumn2.Width = 86;
            // 
            // bindDataWorker
            // 
            this.bindDataWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.bindDataWorker_DoWork);
            this.bindDataWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bindDataWorker_RunWorkerCompleted);
            // 
            // numberTypeDataGridViewTextBoxColumn
            // 
            this.numberTypeDataGridViewTextBoxColumn.DataPropertyName = "NumberType";
            this.numberTypeDataGridViewTextBoxColumn.DataSource = this.bsPhoneNumberTypes;
            this.numberTypeDataGridViewTextBoxColumn.DisplayMember = "NumberType";
            this.numberTypeDataGridViewTextBoxColumn.HeaderText = "Phone Type";
            this.numberTypeDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numberTypeDataGridViewTextBoxColumn.Name = "numberTypeDataGridViewTextBoxColumn";
            this.numberTypeDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.numberTypeDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.numberTypeDataGridViewTextBoxColumn.Width = 118;
            // 
            // colNumber
            // 
            this.colNumber.DataPropertyName = "Number";
            this.colNumber.HeaderText = "Number";
            this.colNumber.MinimumWidth = 50;
            this.colNumber.Name = "colNumber";
            this.colNumber.Width = 96;
            // 
            // colDateCreated
            // 
            this.colDateCreated.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.colDateCreated.DataPropertyName = "DateCreated";
            this.colDateCreated.HeaderText = "Update Date";
            this.colDateCreated.MinimumWidth = 6;
            this.colDateCreated.Name = "colDateCreated";
            this.colDateCreated.ReadOnly = true;
            this.colDateCreated.Width = 127;
            // 
            // UpdateContact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnlDetails);
            this.Name = "UpdateContact";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Contact Details";
            ((System.ComponentModel.ISupportInitialize)(this.pnlDetails)).EndInit();
            this.pnlDetails.ResumeLayout(false);
            this.pnlDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup1.Panel)).EndInit();
            this.kryptonHeaderGroup1.Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonHeaderGroup1)).EndInit();
            this.kryptonHeaderGroup1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.kryptonPanel1)).EndInit();
            this.kryptonPanel1.ResumeLayout(false);
            this.kryptonPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bsPhonebookEntry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hdrDetails.Panel)).EndInit();
            this.hdrDetails.Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.hdrDetails)).EndInit();
            this.hdrDetails.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pnlContactDetails)).EndInit();
            this.pnlContactDetails.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgPhonebookEntries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsPhoneNumberTypes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bsNumbers)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn2;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel pnlDetails;
        private ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup hdrDetails;
        private ComponentFactory.Krypton.Toolkit.KryptonHeader hdrActions;
        private ComponentFactory.Krypton.Toolkit.ButtonSpecAny btnSaveContact;
        private ComponentFactory.Krypton.Toolkit.KryptonHeader hdrPhonebook;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel pnlContactDetails;
        private ComponentFactory.Krypton.Toolkit.ButtonSpecAny btnCancel;
        private ComponentFactory.Krypton.Toolkit.KryptonDataGridView dgPhonebookEntries;
        private System.Windows.Forms.BindingSource bsPhoneNumberTypes;
        private System.ComponentModel.BackgroundWorker bindDataWorker;
        private ComponentFactory.Krypton.Toolkit.KryptonHeaderGroup kryptonHeaderGroup1;
        private ComponentFactory.Krypton.Toolkit.KryptonPanel kryptonPanel1;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel lblSurname;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox txtSurname;
        private System.Windows.Forms.BindingSource bsPhonebookEntry;
        private ComponentFactory.Krypton.Toolkit.KryptonLabel lblName;
        private ComponentFactory.Krypton.Toolkit.KryptonTextBox txtName;
        private System.Windows.Forms.BindingSource bsNumbers;
        private System.Windows.Forms.DataGridViewComboBoxColumn numberTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDateCreated;
    }
}