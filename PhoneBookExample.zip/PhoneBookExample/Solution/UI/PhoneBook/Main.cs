﻿using ComponentFactory.Krypton.Toolkit;
using DMS.UI;
using Phonebook.UI;
using PhoneBook.Forms;
using PhoneBook.PhonebookService;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace PhoneBook
{
    public partial class Main : KryptonForm
    {
        private ProgressControl _progressControl = null;
        private List<PhonebookEntry> _phoneBookEntries = null; //phonebook entries
        private List<PhonebookEntryNumber> _pben = null; //phonebook number entries
        private int numberIndex = -1;
        public Main()
        {
            InitializeComponent();
            LoadData();
        }
        private void LoadData()
        {
            _progressControl = new ProgressControl();

            _progressControl = new ProgressControl
            {
                BackColor = Color.WhiteSmoke,
                RingColor = Color.DarkGray,
                ForeColor = Color.Black,
                Text = "Loading Data",
                Font = new Font("Segoe UI", 10)
            };
            _progressControl.Rotate = true;
            _progressControl.Show(this);

            dataLoadWorker.RunWorkerAsync();
        }

        private void BindData()
        {
            PhonebookServiceClient client = null;
            try
            {
                client = new PhonebookServiceClient();
                _phoneBookEntries = client.CachePhonebookEntries();

                client.Close();

                if (_phoneBookEntries != null)
                {
                    _pben = new List<PhonebookEntryNumber>();
                    foreach (PhonebookEntry pe in _phoneBookEntries)
                        _pben.AddRange(pe.Numbers);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (client != null && client.State != System.ServiceModel.CommunicationState.Closed)
                    client.Abort();
            }
        }
        private void DataLoadWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            BindData();
        }

        private void DataLoadWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            Sort();
            _progressControl.Dispose();
        }

        /// <summary>
        /// This method gets invoked on startup, as well as when the text is modified in the filter text box, it orders the list based on the First Name of the phonebook entry.
        /// </summary>
        private void Sort()
        {
            if (_phoneBookEntries != null)
            {
                string filter = txtFilter.Text;

                #region Filter on both the Name and Surname
                var s = (from entry in _phoneBookEntries.FindAll(x =>
                {
                    return (string.IsNullOrEmpty(filter)
                        || (x.FirstName != null && x.FirstName.IndexOf(filter, StringComparison.CurrentCultureIgnoreCase) != -1)
                        || (x.Surname != null && x.Surname.IndexOf(filter, StringComparison.CurrentCultureIgnoreCase) != -1)
                        );
                }).OrderBy(x => x.FirstName)
                         select new PhonebookEntry
                         {
                             FirstName = entry.FirstName,
                             Surname = entry.Surname,
                             Numbers = entry.Numbers,
                             DateCreated = entry.DateCreated,
                             PhonebookEntryId = entry.PhonebookEntryId
                         });

                if (s.ToList().Count != 0)
                    bsPhoneEntries.DataSource = new BindingListView<PhonebookEntry>(s.ToList());
                #endregion

                #region Filter the telephone number
                else
                {
                    List<PhonebookEntryNumber> _filteredNumEntries = _pben.FindAll(x => x.Number != null && x.Number.IndexOf(filter, StringComparison.CurrentCultureIgnoreCase) != -1);

                    bsPhoneEntries.DataSource = _phoneBookEntries.FindAll(x =>
                    _filteredNumEntries.Exists(y => y.PhonebookEntryId == x.PhonebookEntryId)).OrderBy(x => x.FirstName);
                }
                #endregion
            }
        }

        private void txtFilter_TextChanged(object sender, EventArgs e)
        {
            Sort();
        }

        private void dgPhonebookEntries_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
                CellClicked(e, false);
        }

        private void CellClicked(DataGridViewCellEventArgs e, bool doubleClicked)
        {
            numberIndex = bsPhoneEntries.Position;

            if (dgPhonebookEntries.Rows[e.RowIndex].DataBoundItem is PhonebookEntry)
            {
                PhonebookEntry entry = (PhonebookEntry)((DataGridViewRow)dgPhonebookEntries.Rows[e.RowIndex]).DataBoundItem;
                entry.PhonebookEntryId = entry.Numbers != null && entry.Numbers.Count != 0 ? entry.Numbers.FirstOrDefault().PhonebookEntryId : entry.PhonebookEntryId;

                if (e.ColumnIndex == colEdit.Index || doubleClicked)
                    ShowContactDetails(true, numberIndex);

                if (e.ColumnIndex == colDelete.Index)
                    DeletePhoneBookEntry(entry);
            }
        }

        /// <summary>
        /// This method Displays the contact details edit form, for both adding and editing data entries
        /// </summary>
        /// <param name="edit">Equals true when in edit mode</param>
        /// <param name="numberIndex">The index of the phonebook entry selected</param>
        private void ShowContactDetails(bool edit, int numberIndex)
        {
            UpdateContact frmContact = new UpdateContact
            {
                Edit = edit,
                PhonebookEntry = edit ? (PhonebookEntry)bsPhoneEntries.Current : new PhonebookEntry { DateCreated = DateTime.Now}
            };
            if((DialogResult)frmContact.ShowDialog() == DialogResult.OK)
            {
                if (edit)
                    _phoneBookEntries[numberIndex] = frmContact.PhonebookEntry;
                else
                    _phoneBookEntries.Add(frmContact.PhonebookEntry);

                SavePhoneBookEntries(frmContact.PhonebookEntry);
            }
        }

        /// <summary>
        /// This method accepts a PhonebookEntry as data block business entity, it will the save the information in both the service cache as well as the datastore
        /// </summary>
        /// <param name="entry">PhonebookEntry</param>
        private void SavePhoneBookEntries(PhonebookEntry entry)
        {
            PhonebookServiceClient client = null;
            try
            {
                client = new PhonebookServiceClient();
                client.UpdatePhonebookEntry(entry);
                client.Close();
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (client != null && client.State != System.ServiceModel.CommunicationState.Closed)
                    client.Abort();
            }
        }

        /// <summary>
        /// This method accepts a PhonebookEntry as data block business entity, it will remove the data block in both the service cache as well as the datastore
        /// </summary>
        /// <param name="entry">PhonebookEntry</param>
        private void DeletePhoneBookEntry(PhonebookEntry entry)
        {
            if (bsPhoneEntries.Count != 0)
            {
                PhonebookServiceClient client = null;
                try
                {
                    client = new PhonebookServiceClient();
                    client.DeletePhonebookEntry(entry.PhonebookEntryId);
                    client.Close();

                    _phoneBookEntries.RemoveAll(x => x.PhonebookEntryId == entry.PhonebookEntryId);
                    Sort();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (client != null && client.State != System.ServiceModel.CommunicationState.Closed)
                        client.Abort();
                }
            }
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            ShowContactDetails(false, -1);
        }

        private void dgPhonebookEntries_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
                CellClicked(e, true);
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
