﻿using System;
using System.Linq;
using ComponentFactory.Krypton.Toolkit;
using Phonebook.UI;

namespace Phonebook.UI
{
    public class HintTextBox : KryptonTextBox
    {
        private string _hint = "";
        public string Hint
        {
            get { return _hint; }
            set
            {
                _hint = value;
                this.SetHint(_hint);
            }
        }
    }

    public static class HintTextBoxExtension
    {
        private static readonly PlatformID[] supportedPlatforms = new PlatformID[] { PlatformID.Win32NT, PlatformID.Win32S, PlatformID.Win32Windows };
        public static void SetHint(this KryptonTextBox textBox, string hint)
        {
            const int EM_SETCUEBANNER = 0x1501;
            if (supportedPlatforms.Contains(Environment.OSVersion.Platform))
            {
                Win32.SendMessage(textBox.TextBox, EM_SETCUEBANNER, 0, hint);
            }
            textBox.Invalidate();
        }
    }
}
