﻿using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace Phonebook.UI
{
    public class BindingListView<T> : List<T>, IBindingListView where T : new()
    {
        public BindingListView(List<T> sourceList)
        {
            AddRange(sourceList);
            innerList = sourceList;
        }

        private readonly List<T> innerList = null;
        private readonly List<PropertyDescriptor> indexes = new List<PropertyDescriptor>();

        private ListSortDescriptionCollection _sorts = null;

        #region IBindingListView Members

        public void ApplySort(ListSortDescriptionCollection sorts)
        {
            _sorts = sorts;
            if (_sorts != null)
            {
                Sort((a, b) =>
                {
                    int comparison = 0;
                    foreach (ListSortDescription listSortDescription in sorts)
                    {
                        comparison = Compare(listSortDescription.PropertyDescriptor,
                            listSortDescription.SortDirection,
                            a,
                            b);

                        if (comparison != 0)
                        {
                            break;
                        }
                    }
                    return comparison;
                });
            }

            if (ListChanged != null)
            {
                ListChanged(this, new ListChangedEventArgs(ListChangedType.Reset, -1));
            }
        }

        private string _filter = "";
        public string Filter
        {
            get
            {
                return _filter;
            }
            set
            {
                _filter = value;
                FilterList();
            }
        }

        private Predicate<T> _predicateFilter = null;
        public Predicate<T> PredicateFilter
        {
            get
            {
                return _predicateFilter;
            }
            set
            {
                _predicateFilter = value;
                FilterList();
            }
        }

        private void FilterList()
        {
            if (_predicateFilter == null)
            {
                RemoveFilter();
            }
            else
            {
                this.Clear();
                this.AddRange(innerList.FindAll(_predicateFilter));
            }
            if (_sorts != null)
            {
                ApplySort(_sorts);
            }
            else if (SortProperty != null)
            {
                ApplySort(SortProperty, _sortDirection);
            }

            if (ListChanged != null)
            {
                ListChanged(this, new ListChangedEventArgs(ListChangedType.Reset, -1));
            }
        }

        public void RemoveFilter()
        {
            this.Clear();
            this.AddRange(innerList);
        }

        public ListSortDescriptionCollection SortDescriptions
        {
            get { return _sorts; }
        }

        public bool SupportsAdvancedSorting
        {
            get { return true; }
        }

        public bool SupportsFiltering
        {
            get { return false; }
        }

        #endregion

        #region IBindingList Members

        public void AddIndex(PropertyDescriptor property)
        {
            if (property.ComponentType == typeof(T))
            {
                indexes.Add(property);
            }
            else
            {
                throw new ArgumentOutOfRangeException("Property does not belong to class type " + typeof(T).Name);
            }
        }

        public object AddNew()
        {
            T newItem = new T();
            Add(newItem);
            return newItem;
        }

        public bool AllowEdit
        {
            get { return true; }
        }

        public bool AllowNew
        {
            get { return true; }
        }

        public bool AllowRemove
        {
            get { return true; }
        }

        public void ApplySort(PropertyDescriptor property, ListSortDirection direction)
        {
            SortProperty = property;
            _sortDirection = direction;
            Sort((a, b) =>
            {
                return Compare(property, direction, a, b);
            }
            );
        }

        private static int Compare(PropertyDescriptor property, ListSortDirection direction, object a, object b)
        {
            object valueA = property.GetValue(a);
            object valueB = property.GetValue(b);
            if (valueA is IComparable && valueB is IComparable)
            {
                if (direction == ListSortDirection.Ascending)
                {
                    return ((IComparable)valueA).CompareTo(valueB);
                }
                else
                {
                    return ((IComparable)valueB).CompareTo(valueA);
                }
            }
            return 0;
        }

        public int Find(PropertyDescriptor property, object key)
        {
            return FindIndex((x) => property.GetValue(x) == key);
        }

        public bool IsSorted
        {
            get { return SortProperty != null; }
        }

        public event ListChangedEventHandler ListChanged;

        public void RemoveIndex(PropertyDescriptor property)
        {
            int index = indexes.FindIndex((x) => x.Name == property.Name);
        }

        public void RemoveSort()
        {
            SortProperty = null;
        }

        private ListSortDirection _sortDirection;
        public ListSortDirection SortDirection
        {
            get { return _sortDirection; }
        }

        public PropertyDescriptor SortProperty { get; private set; } = null;

        public bool SupportsChangeNotification
        {
            get { return true; }
        }

        public bool SupportsSearching
        {
            get { return true; }
        }

        public bool SupportsSorting
        {
            get { return true; }
        }

        #endregion
    }
}
